export interface UserDTO {
  id?: string;
  email?: string;
  uname?: string;
  contact?: string;
  profile?: string;
  address?: string;
}
export interface PeopleErrorDTO {
  email?: string | null;
  uname?: string;
  contact?: string;
  profile?: string;
  address?: string;
}
export interface CompetitionDTO {
  id?: string | undefined;
  cname?: string;
  cid?: string;
  rounds?: RoundsDataDTO[];
}
export interface RoundsDataDTO {
  id: string;
  label: string;
}
export interface TError {
  cname?: string;
}
export interface RulesDTO {
  id?: string;
  value?: string;
}
export interface RuleError {
  rule?: string;
}
export interface LoginDTO {
  email?: string | null;
  id?: string | null;
  contact?: string | null;
  photourl?: string | null;
  fullname?: string | null;
}
export interface SubtabDTO {
  Participants: string;
  Rules: string;
  LeaderBoard: string;
}
export interface SelectedroundsDTO {
  id?: string | undefined;
}
