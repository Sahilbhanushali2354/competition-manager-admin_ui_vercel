const Leaderboard = () => {
    return (
        <div>
            LeaderBoard
        </div>
    )
}

export default Leaderboard
