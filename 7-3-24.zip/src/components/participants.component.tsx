import { Select, Table, Image, Button, message, Spin } from "antd";
import { UserDTO } from "../types/input.types";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  setDoc,
} from "firebase/firestore";
import { useEffect, useState } from "react";
import { FStore } from "../common/config/router/firebase.config";
import { useRecoilState, useRecoilValue } from "recoil";
import { AtomAllPeople, SelectedRoundAtom } from "../store/atom.store";
import { useNavigate, useParams } from "react-router-dom";

const Participants = () => {
  const selectedRound = useRecoilValue(SelectedRoundAtom);
  const [loader, setLoader] = useState<boolean>(false);
  const { id } = useParams();
  const [peopleList, setPeopleList] = useRecoilState(AtomAllPeople);
  const [selectedParticipants, setSelectedParticipants] = useState<UserDTO[]>(
    [] as UserDTO[]
  );
  const navigate = useNavigate();
  useEffect(() => {
    console.log("selectedRound", selectedRound);
  }, [selectedRound]);

  useEffect(() => {
    if (!peopleList.length) getParticipantsData();
  }, []);

  useEffect(() => {
    if (selectedRound) fetchSelectedParticipants();
  }, [selectedRound, id]);

  const handleChange = (_: string, option: any) => {
    console.log(option);

    setSelectedParticipants(option);
  };

  const getParticipantsData = async () => {
    const x: UserDTO[] = [] as UserDTO[];
    const q = query(collection(FStore, "PEOPLE"));
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      // console.log(doc.id, " => ", doc.data());
      let _data = doc.data();
      _data.id = doc.id;
      x.push(_data);
    });
    setPeopleList(x);
  };

  const SaveData = async () => {
    setLoader(true);

    setDoc(
      doc(FStore, "COMPETITION", id, selectedRound as string, "PARTICIPANTS"),
      { ["DATA"]: selectedParticipants }
    )
      .then(() => {
        selectedParticipants.length > 1
          ? message.success("People Stored SuccessFully")
          : selectedParticipants.length == 1
          ? message.success("Person Stored SuccessFully")
          : message.success("All People Removed SuccessFully");
        setLoader(false);
      })
      .catch((error) => {
        setLoader(false);
        console.log("error occured in saveData", error);
      });
    //  console.log("error occured in saveData", error));

    // setLoader(true);
    // catch((error) => console.log("Error occured in save data", error));
  };

  const fetchSelectedParticipants = async () => {
    const docref = doc(
      FStore,
      "COMPETITION",
      id,
      selectedRound as string,
      "PARTICIPANTS"
    );
    const docSnap = await getDoc(docref);
    if (docSnap.exists()) {
      const data = docSnap.data();
      let x = data?.DATA ?? [];
      setSelectedParticipants(x);
    } else {
      setSelectedParticipants([]);
    }
  };

  const columns = [
    {
      title: "Profile",
      dataIndex: "profile",
      render: (profile: string) => {
        return <Image width={50} src={profile} />;
      },
    },
    {
      title: "Username",
      dataIndex: "uname",
    },
    {
      title: "Email",
      dataIndex: "email",
    },
    {
      title: "Phone Number",
      dataIndex: "contact",
    },
    {
      title: "Address",
      dataIndex: "address",
    },
    {
      render: () => (
        <Button type="link" onClick={() => navigate("/feedback")}>
          Feedback
        </Button>
      ),
    },
  ];

  return (
    <Spin spinning={loader}>
      <Select
        mode="multiple"
        style={{ width: "100%" }}
        placeholder="select People Data"
        onChange={handleChange}
        fieldNames={{ value: "uname", label: "uname" }}
        // optionLabelProp="uname"
        options={peopleList.map((participant) => ({
          ...participant,
          label: participant.uname,
          value: participant.uname,
        }))}
        value={selectedParticipants as any}
      />
      <Table dataSource={selectedParticipants} columns={columns} />
      <div style={{ float: "right" }}>
        <Button type="primary" onClick={SaveData}>
          SAVE
        </Button>
      </div>
    </Spin>
  );
};

export default Participants;

// import { Select, Table, Image, Button } from "antd";
// import { UserDTO } from "../types/input.types";
// import {
//   collection,
//   doc,
//   getDoc,
//   getDocs,
//   query,
//   setDoc,
// } from "firebase/firestore";
// import { useEffect, useState } from "react";
// import { FStore } from "../common/config/router/firebase.config";
// import { useRecoilValue } from "recoil";
// import { SelectedRoundAtom } from "../store/atom.store";
// import { useParams } from "react-router-dom";

// const Participants = () => {
//   const { id } = useParams();
//   const [selectedTableData, setSelectedTableData] = useState([]);
//   const [selectedUName, setSelectedUName] = useState<UserDTO[]>([] as UserDTO[]);
//   const [SelectedParticipants, setSelectedParticipants] = useState<UserDTO[]>(
//     [] as UserDTO[]
//   );
//   const selectedRound = useRecoilValue(SelectedRoundAtom);

//   useEffect(() => {
//     console.log("selectedRound", selectedRound);
//   }, [selectedRound]);

//   useEffect(() => {
//     if (!SelectedParticipants.length) getAllParticipantsData();
//   }, []);
//   useEffect(() => {
//     const filteredData = SelectedParticipants.filter((participant) =>
//       SelectedParticipants.includes(participant.uname as UserDTO)
//     );
//     setSelectedTableData(filteredData as []);
//   }, [SelectedParticipants]);

//   useEffect(() => {
//     fetchSelectedParticipants();
//   }, [SelectedParticipants]);

//   const handleChange = (value: string[]) => {
//     // console.log(`selected ${value}`);
//     setSelectedUName(value as UserDTO[]);
//   };

//   const getAllParticipantsData = async () => {
//     const x: UserDTO[] = [] as UserDTO[];
//     const q = query(collection(FStore, "PEOPLE"));
//     const querySnapshot = await getDocs(q);
//     querySnapshot.forEach((doc) => {
//       let _data = doc.data();
//       _data.id = doc.id;
//       x.push(_data);
//     });
//     setSelectedParticipants(x);
//   };

//   const SaveData = async () => {
//     setDoc(
//       doc(FStore, "COMPETITION", id, selectedRound as string, "PARTICIPANTS"),
//       {
//         ["DATA"]: selectedTableData,
//       }
//     );
//   };

//   const fetchSelectedParticipants = async () => {
//     const docref = doc(
//       FStore,
//       "COMPETITION",
//       id,
//       selectedRound as string,
//       "PARTICIPANTS"
//     );
//     const docSnap = await getDoc(docref);
//     if (docSnap.exists()) {
//       const data = docSnap.data();
//       let x = data.DATA.map((x: UserDTO) => x.uname);
//       setSelectedUName(x);
//     } else {
//       setSelectedUName([]);
//     }
//   };

//   const columns = [
//     {
//       title: "Profile",
//       dataIndex: "profile",
//       render: (profile: string) => {
//         return <Image width={50} src={profile} />;
//       },
//     },
//     {
//       title: "Username",
//       dataIndex: "uname",
//     },
//     {
//       title: "Email",
//       dataIndex: "email",
//     },
//     {
//       title: "Phone Number",
//       dataIndex: "contact",
//     },
//     {
//       title: "Address",
//       dataIndex: "address",
//     },
//   ];

//   return (
//     <div>
//       <Select
//         mode="multiple"
//         style={{ width: "100%" }}
//         placeholder="select People Data"
//         onChange={handleChange}
//         options={SelectedParticipants.map((participant) => ({
//           label: participant.uname,
//           value: participant.uname,
//         }))}
//         value={selectedUName as []}
//       />
//       <Table
//         dataSource={SelectedParticipants.filter((participant) =>
//           selectedUName.includes(participant.uname as UserDTO)
//         )}
//         columns={columns}
//       />
//       <div style={{ float: "right" }}>
//         <Button type="primary" onClick={SaveData}>
//           SAVE
//         </Button>
//       </div>
//     </div>
//   );
// };

// export default Participants;
