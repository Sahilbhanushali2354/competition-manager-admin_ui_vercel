import { Button, Tabs } from "antd";
import { useParams } from "react-router-dom";
import {
  AllCompetitionAtom,
  SelectedCompetitionAtom,
  SelectedRoundAtom,
} from "../store/atom.store";
import { useRecoilState } from "recoil";
import { CompetitionDTO, RoundsDataDTO } from "../types/input.types";
import { useEffect } from "react";
import "../tab.css";
import { collection, doc, getDocs, updateDoc } from "firebase/firestore";
import { FStore } from "../common/config/router/firebase.config";
import Participants from "../components/participants.component";
import Rules from "../components/rules.component";
import LeaderBoard from "../components/leaderboard.component";

const CompetitionTabs = () => {
  const [selectedCompetition, setSelectedCompetition] =
    useRecoilState<CompetitionDTO>(SelectedCompetitionAtom);
  const [allcompetitionData, setAllCompetitionData] =
    useRecoilState(AllCompetitionAtom);
  // const [allSubTab,setAllSubTab] = useRecoilState(SubTabAtom)
  const { id } = useParams();
  const [selectedRound, setSelectedRound] = useRecoilState(SelectedRoundAtom);
  // const [selectedSubTab, setSelectedSubTab] = useState("" || undefined);
  useEffect(() => {
    // debugger;
    if (!allcompetitionData.length) {
      getdata();
    } else {
      const _matchid = allcompetitionData.find((x) => x.id == id);
      if (_matchid) {
        setSelectedCompetition(_matchid.rounds as {});
        setSelectedRound(_matchid.rounds && _matchid.rounds[0].id);
      }
    }
  }, []);

  const data = [
    {
      id: "1",
      label: "Participants",
    },
    {
      id: "2",
      label: "Rules",
    },
    {
      id: "3",
      label: "LeaderBoard",
    },
  ];

  const ParantTabChange = (key: string) => {
    console.log("parantabchange", key);
    setSelectedRound(key as string);
  };

  const addround = async () => {
    // debugger

    const lastRoundLabel =
      selectedCompetition.rounds &&
      selectedCompetition.rounds[selectedCompetition.rounds.length - 1]?.label;

    const lastRoundNumber =
      (lastRoundLabel && parseInt(lastRoundLabel.split(" ")[1])) || 0;

    const newRoundLabel = `Round ${lastRoundNumber + 1}`;
    const newRound: RoundsDataDTO = {
      id: Math.random().toString(),
      label: newRoundLabel,
    };
    // setTab([...tab,newround)
    // let _newData = {...selectedCompetition}
    // let _data = [...(_newData.rounds ?? [])];[]
    // _data.push(newround);
    // _newData.rounds = _data;
    // console.log("------------------_data", _newData);
    // // setNewTab(_data);
    // setSelectedCompetition(_newData);

    let _selectedCompetition = { ...selectedCompetition };
    let _selectedRounds = [...(_selectedCompetition.rounds ?? [])];
    _selectedRounds.push(newRound);
    _selectedCompetition.rounds = _selectedRounds;
    setSelectedCompetition(_selectedCompetition);
    if (selectedCompetition && selectedCompetition.id) {
      const UpdateRef = doc(
        FStore,
        "COMPETITION",
        _selectedCompetition.id as string
      );

      // Set the "capital" field of the city 'DC'
      await updateDoc(UpdateRef, _selectedCompetition);
      // console.log(
      //   "------------------_selectedCompetition ID",
      //   _selectedCompetition.id
      // );
    }
    await getdata();
  };
  const getdata = async () => {
    const querySnapshot = await getDocs(collection(FStore, "COMPETITION"));
    let x: CompetitionDTO[] = [] as CompetitionDTO[];

    querySnapshot.forEach((doc) => {
      // console.log("-----doc.data", doc.data());
      let data = doc.data();
      data.id = doc.id;
      // console.log("->doc id", doc.id);

      x.push(data as CompetitionDTO);
    });
    setAllCompetitionData(x);

    const _selectdata = x.find((selecteddata) => selecteddata.id == id);
    if (_selectdata) setSelectedCompetition(_selectdata);
    setSelectedRound(_selectdata?.rounds && _selectdata?.rounds[0].id);
    //   console.log("----------------_selectdata", _selectdata);
  };

  // console.log("------------>AllCompetitionData", allcompetitionData);
  // console.log(
  //   "------------>SelectedCompetitionData",
  //   selectedCompetition.rounds
  // );

  return (
    <div>
      <div style={{ float: "right" }}>
        <Button type="primary" onClick={addround}>
          ADD ROUNDS
        </Button>
      </div>

      <div style={{ display: "flex", flexDirection: "row" }}>
        <Tabs
          onChange={(key: string) => ParantTabChange(key)}
          items={selectedCompetition.rounds?.map((round: RoundsDataDTO) => {
            return {
              label: round.label,
              key: round.id,
              children: (
                <Tabs
                  items={data.map((rounds) => {
                    return {
                      label: rounds.label,
                      key: rounds.id,
                      children:
                        rounds.label == "Participants" ? (
                          <Participants />
                        ) : rounds.label == "Rules" ? (
                          <Rules />
                        ) : (
                          <LeaderBoard />
                        ),
                    };
                  })}
                />
              ),
            };
          })}
        />
      </div>
    </div>
  );
};
export default CompetitionTabs;
