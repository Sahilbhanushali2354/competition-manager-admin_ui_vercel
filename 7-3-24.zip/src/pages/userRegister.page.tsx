// import { Button, Input, Space, Spin, message } from "antd";
// import { ChangeEvent, useState } from "react";
// import { TError, UserDTO } from "../input.types";
// import { FStore } from "../configs/firebase.config";
// import { collection, addDoc } from "firebase/firestore";
// import { useNavigate } from "react-router-dom";
// import { doc, updateDoc } from "firebase/firestore";
// import { getStorage, ref, uploadBytes } from "firebase/storage";

// type Props = {
//   data?: UserDTO;
//   setIsModalOpen?: any;
//   setData?: (d: UserDTO) => void;
//   editdisable?: boolean;
// };

// function UserRegister(p: Props) {
//   const isDialogPage = p.data;
//   const isRegisterPage = p.data;

//   // console.log("-----p.data", p.data);
//   const [formData, setFormData] = useState<UserDTO>(
//     p.data ? p.data : ({} as UserDTO) //ternary operator for if p.data then p.data otherwise as it is
//   );
//   const [loader, setLoader] = useState(false);
//   const [errorMessage, SetErrorMessage] = useState<TError>({} as TError);
//   const [File] = useState<File>();
//   const [userfile, setUserFile] = useState<File>();

//   const navigate = useNavigate();

//   // const [updateData, SetUpdateData] = useState({email: p.data.email});

//   const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
//     let name1 = e.target.name;
//     let val = e.target.value;
  //   const files = e.target.files;
  //   if (files && files.length > 0) {
  //     // const file0 = files[0];
  //     setUserFile(files[0]);
  //   }
  //   setFormData({ ...formData, [name1]: val });
  //   if (val) {
  //     SetErrorMessage({ ...errorMessage, [name1]: "" });
  //   }
  // };

//   const handleSubmit = async () => {
//     // console.log(formData.email, "-----------FORMData");
//     // const mailreg = "/@gmail.com$/";
//     let _error = { ...errorMessage };
//     /* console.log(_error); */
//     if (!formData.uname) _error = { ..._error, ["uname"]: "Enter Your name" };
//     /* console.log(_error); */
//     if (!formData.email) _error = { ..._error, ["email"]: "Enter Your Email" };
//     /* console.log(_error); */
//     // if (!formData.email.match(mailreg))
//     //   _error = { ..._error, ["email"]: "Enter Valid Email" };

//     if (!formData.dob)
//       _error = { ..._error, ["dob"]: "Enter Your Date of Birth" };
//     if (!formData.profile)
//       _error = { ..._error, ["profile"]: "Select Profile Photo" };
//     /* console.log(_error); */
    // if (formData.profile) {
    //   const extensions = [
    //     "image/apng",
    //     "image/avif",
    //     "image/gif",
    //     "image/jpeg",
    //     "image/jpg",
    //     "image/png",
    //     "image/svg+xml",
    //     "image/webp",
    //   ];
    //   if (userfile && userfile.name.length > 0) {
    //     if (!extensions.includes(userfile.type)) {
    //       console.log("--------userfile name", userfile.name);

    //       console.log("--------userfile", userfile.type);
    //       _error = { ..._error, ["profile"]: "Enter Valid Profile Photo" };
    //       SetErrorMessage(_error);
    //     }
    //   }
    // }

//     if (!formData.address)
//       _error = { ..._error, ["address"]: "Enter Your Address" };
//     /* console.log(_error); */

//     if (!formData.designation)
//       _error = { ..._error, ["designation"]: "Enter Your Designation" };
//     /* console.log(_error); */

//     if (!formData.empcode) {
//       _error = { ..._error, ["empcode"]: "Enter Employee Code" };
//       /* console.log(_error); */

//       SetErrorMessage(_error);
//     } else {
//       message.open({ content: "Data Added SuccessFully!", type: "success" });
//       console.log("-------formData.profile", formData.profile);
//       setLoader(true);
//       await addData();
//       addprofile();
//       // addUser();
//       setLoader(false);
//       navigate("/users");
//     }
//   };

//   // const handleprofile = (e: ChangeEvent<HTMLInputElement>) => {
//   //   let _error = { ...errorMessage };
//   //   const files = e.target.files;
//   // };

  // const addprofile = () => {
  //   const storage = getStorage();
  //   const storageRef = ref(storage, `folder1/${File?.name}`);
  //   console.log("----------storageRef", storageRef);
  //   // 'file' comes from the Blob or File API

  //   console.log(formData.profile);
  //   const metadata = {
  //     contentType: "image/jpeg",
  //   };
  //   if (!File) return;
  //   uploadBytes(storageRef, File, metadata)
  //     .then((snapshot) => {
  //       console.log("-----snapshot", snapshot.ref);
  //     })
  //     .catch((err) => {
  //       console.log(err);
  //     });
  // };

//   // const addUser = () => {
//   //   createUserWithEmailAndPassword(auth, formData.email, "123123")
//   //     .then((/* userCredential */) => {
//   //       // Signed up
//   //       // const user = userCredential.user;
//   //       // console.log(userCredential); // ...
//   //     })
//   //     .catch(() => {
//   //       message.open({ content: "Enter Valid Data!", type: "error" });
//   //       // const errorCode = error.code;
//   //       // const errorMessage = error.message;
//   //       // ..
//   //     });
//   // };

//   const addData = async () => {
//     try {
//       await addDoc(collection(FStore, "USERS"), formData);
//     } catch (e) {}
//   };
//   console.log(p.data);
//   const handleUpdate = async () => {
//     // debugger
//     let _error = { ...errorMessage };
//     // /* console.log(_error); */

//     if (!formData.uname) _error = { ..._error, ["uname"]: "Enter Your name" };
//     // /* console.log(_error); */
//     if (!formData.email) _error = { ..._error, ["email"]: "Enter Your Email" };
//     // /* console.log(_error); */

//     if (!formData.dob)
//       _error = { ..._error, ["dob"]: "Enter Your Date of Birth" };
//     // /* console.log(_error); */

//     if (!formData.address)``
//       _error = { ..._error, ["address"]: "Enter Your Address" };
//     // /* console.log(_error); */

//     if (!formData.designation)
//       _error = { ..._error, ["designation"]: "Enter Your Designation" };
//     // /* console.log(_error); */

//     if (!formData.empcode) {
//       _error = { ..._error, ["empcode"]: "Enter Employee Code" };
//       SetErrorMessage(_error);
//     } else {
//       if (p.data?.id) {
//         setLoader(true);
//         const updateRef = doc(FStore, "USERS", p.data?.id);
//         // debugger
//         // console.log("updateRef", updateRef);
        // await updateDoc(updateRef, formData);
//         // p.setFilterData(formData);
//         // console.log("-----formdata", formData);
//         // console.log("-----updateref", updateRef.id);
//         p.setData && p.setData(formData);
//         setLoader(false);
//         p.setIsModalOpen(false);
//         message.open({
//           content: "Data updated successfully!",
//           type: "success",
//         });
//         // console.log(formData.empcode);
//       }
//     }
//   };

//   return (
//     <Spin size="large" spinning={loader} className="main-container">
//       <div className="container">
//         <div className="form-container">
//           <div className="heading">
//             <h3>Regitstration Form</h3>
//           </div>
//           <div className="input-container">
//             <div className="inputs">
//               <label>Name</label>
//               <Input
//                 value={formData.uname}
//                 type="text"
//                 name="uname"
//                 onChange={handleChange}
//               ></Input>

//               <div style={{ color: "red" }}>{errorMessage.uname}</div>
//             </div>
//             <div className="inputs">
//               <label>Email</label>
//               <Input
//                 disabled={p.editdisable}
//                 value={formData.email}
//                 type="email"
//                 name="email"
//                 onChange={handleChange}
//               ></Input>

//               <div style={{ color: "red" }}>{errorMessage.email}</div>
//             </div>
//             <div className="inputs">
//               <label>DOB</label>
//               <Input
//                 value={formData.dob}
//                 type="date"
//                 name="dob"
//                 onChange={handleChange}
//               ></Input>
//               <div style={{ color: "red" }}>{errorMessage.dob}</div>
//             </div>
//             <div className="inputs">
//               <label>Address</label>
//               <Input
//                 value={formData.address}
//                 type="textarea"
//                 name="address"
//                 onChange={handleChange}
//               ></Input>
//               <div style={{ color: "red" }}>{errorMessage.address}</div>
//             </div>
//             <div className="inputs">
//               <label>Profile Photo</label>
//               <Input type="file" name="profile" onChange={handleChange}></Input>
//               <div style={{ color: "red" }}>{errorMessage.profile}</div>
//             </div>
//             <div className="inputs">
//               <label>Designation</label>
//               <Input
//                 value={formData.designation}
//                 type="text"
//                 name="designation"
//                 onChange={handleChange}
//               ></Input>
//               <div style={{ color: "red" }}>{errorMessage.designation}</div>
//             </div>
//             <div className="inputs">
//               <label>Employee code</label>
//               <Input
//                 disabled={p.editdisable}
//                 value={formData.empcode}
//                 type="number"
//                 name="empcode"
//                 onChange={handleChange}
//               ></Input>
//               <div style={{ color: "red" }}>{errorMessage.empcode}</div>
//             </div>
//             <div style={{ padding: "10px" }}>
//               <div className="inputs">
//                 {isDialogPage ? null : (
//                   <Space>
//                     <>
//                       <Button type="primary" onClick={handleSubmit}>
//                         Submit
//                       </Button>
//                       <Button
//                         type="primary"
//                         onClick={() => {
//                           navigate("/users");
//                         }}
//                       >
//                         Back To Users
//                       </Button>
//                     </>
//                   </Space>
//                 )}
//                 {isRegisterPage ? (
//                   <Button type="primary" onClick={handleUpdate}>
//                     Update
//                   </Button>
//                 ) : null}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//       <div className="container-2"></div>
//     </Spin>
//   );
// }
// export default UserRegister;
