import { Input, Radio, RadioChangeEvent, Spin } from "antd";
import { useState } from "react";
import "../feedback.css";

const Feedback = () => {
  const [value, setValue] = useState(1);
  const [loader, setLoader] = useState(false);

  const onChange = (e: RadioChangeEvent) => {
    console.log("radio checked", e.target.value);
    setValue(e.target.value);
  };
  return (
    <Spin spinning={loader}>
      <div className="feedback-container">
        <div className="feedback-item">
          <b>Clarity of Content:</b>
          <div>
            <b>Note that:</b> When choosing your options, consider how was the
            presentation's content, whether elements, text, or overall slide
            supported your understanding, and if any challenges arose in
            grasping the material.
          </div>

          <Radio.Group buttonStyle="solid" onChange={onChange}>
            <div>
              <Radio value={1}>Exceptionally clear content.</Radio>
              <Radio value={2}>Strong content, with a few minor gaps.</Radio>
              <Radio value={3}>
                Adequate content, but overall it lacked clarity.
              </Radio>
              <Radio value={4}>
                Limited understanding, several unexplained content areas.
              </Radio>
              <Radio value={5}>
                Difficulty in understanding, it wasn't easy to follow the
                content.
              </Radio>
            </div>
          </Radio.Group>
        </div>
      </div>
      <div className="feedback-item">
        <b>Engagement Level:</b>
        <div>
          <b>Note that:</b> As you choose your options, consider the presenter's
          ability to keep you engaged through out the presentation and
          accurately convey the fundamental aspects of the subject matter,
          regardless of your personal familiarity with the topic.
        </div>

        <Radio.Group buttonStyle="solid" onChange={onChange}>
          <div>
            <Radio value={1}>Exceptional engagement level</Radio>
            <Radio value={2}>
              Strong engagement level with a few minor gaps.
            </Radio>
            <Radio value={3}>
              Adequate engagement level but some concepts lacked clarity.
            </Radio>
            <Radio value={4}>
              Limited engagement level several important points left unexplained
            </Radio>
            <Radio value={5}>
              Difficulty in engaging with audiance it was difficult to follow or
              comprehend the topic.
            </Radio>
          </div>
        </Radio.Group>
      </div>
      <div className="feedback-item">
        <b>Use of Visuals:</b>
        <div>
          <b>Note that:</b> Please consider factors whether visual elements
          (such as images, graphs, or diagrams) supported your understanding,
          and if any challenges arose in grasping the material.
        </div>

        <Radio.Group buttonStyle="solid" onChange={onChange}>
          <div>
            <Radio value={1}>Exceptionally clear visuals.</Radio>
            <Radio value={2}>Strong visuals, with a few minor gaps.</Radio>
            <Radio value={3}>
              Adequate visuals but some concepts lacked clarity.
            </Radio>
            <Radio value={4}>
              Limited visuals several important points left unexplained.
            </Radio>
            <Radio value={5}>
              Difficulty in visualization as there were no visuals to comprehend
              the topic.
            </Radio>
          </div>
        </Radio.Group>
      </div>
      <div className="feedback-item">
        <b>Explanation Impact:</b>
        <div>
          <b>Note that:</b> Please consider the effectiveness of the
          explanations and storytelling provided by presenter.
        </div>

        <Radio.Group buttonStyle="solid" onChange={onChange}>
          <div>
            <Radio value={1}>Exceptional storytelling and explanation.</Radio>
            <Radio value={2}>Strong Exceptional, with a few minor gaps.</Radio>
            <Radio value={3}>
              Adequate Exceptional, but concepts it lacked clarity.
            </Radio>
            <Radio value={4}>
              Limited explanation, several points remained unexplained.
            </Radio>
            <Radio value={5}>
              Difficulty in explaining the overall topic, couldn't understand it
            </Radio>
          </div>
        </Radio.Group>
      </div>
      <div className="feedback-item">
        <b>Question & Answers:</b>
        <div>
          <b>Note that:</b> Consider instances where the presenter encouraged
          participation, how well questions were addressed, and how these
          interactions influenced your understanding
        </div>

        <Radio.Group buttonStyle="solid" onChange={onChange}>
          <div>
            <Radio value={1}>Exceptionally accurate answers.</Radio>
            <Radio value={2}>Strong answers, with a few minor gaps.</Radio>
            <Radio value={3}>
              Adequate answers, but overall it lacked clarity.
            </Radio>
            <Radio value={4}>
              Limited answers, the presenter struggled to answer questions.
            </Radio>
            <Radio value={5}>
              Difficulty in answering, the presenter was unable to answer
              questions.
            </Radio>
          </div>
        </Radio.Group>
      </div>
      <div className="feedback-item">
        <b>Your Perception:</b>
        <div>
          <b>Note that:</b> Consider the aspects of the presentation that you
          find most appealing or impressive in shaping your perception.
        </div>

        <Radio.Group buttonStyle="solid" onChange={onChange}>
          <div>
            <Radio value={1}>Effectiveness of the slides.</Radio>
            <Radio value={2}>Engaging delivery of the speech.</Radio>
            <Radio value={3}>Thoroughness and coherence of explanation.</Radio>
            <Radio value={4}>
              Effectiveness in addressing questions in the Q&A session.
            </Radio>
            <Radio value={5}>
              Overall, I liked everything about the presentation.
            </Radio>
            <Radio value={6}>
              Other :
              {value === 6 ? (
                <Input style={{ width: 100, marginLeft: 10 }} />
              ) : null}
            </Radio>
          </div>
        </Radio.Group>
      </div>
    </Spin>
  );
};

export default Feedback;
