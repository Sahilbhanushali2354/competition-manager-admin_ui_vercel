const Competition = () => {
  // const allcompetitionData = useRecoilValue(AllCompetitionAtom);
  // const { id } = useParams();

  // console.log('--------------id',id)
  // console.log(
  //   "allcompetitionData round",
  //   allcompetitionData.map((item) => item.round)
  // );
  return <div>{/* <Tabs></Tabs> */}</div>;
};
export default Competition;
