// import { GoPencil } from "react-icons/go";
// import { useState } from "react";
// import { Button, Modal } from "antd";
// import UserRegister from "./userRegister.page";
// import { UserDTO } from "../input.types";

// interface Props {
//   data: UserDTO;
//   setIsModalOpen: boolean;
//   setData?: (d: UserDTO) => void;
// }
// const Dialogpage = (props: Props) => {
//   const [isModalOpen, setIsModalOpen] = useState(false);
//   // console.log("------", props.data);

//   const showModal = () => {
//     setIsModalOpen(props.setIsModalOpen);
//     console.log("------onclick", props.data.email);
//   };
//   const handleCancel = () => {
//     setIsModalOpen(false);
//   };

//   return (
//     <>
//       {/* <img src={edit} onClick={showModal} style={{ width: "50px" }}></img> */}
//       <Button
//         onClick={showModal}
//         style={{ fontSize: "1.15rem" }}
//         type="primary"
//         icon={<GoPencil />}
//       ></Button>
//       <Modal open={isModalOpen} footer={null} onCancel={handleCancel}>
//         <UserRegister
//           editdisable={props.data.email && props.data.empcode ?  true : false}
//           setData={props.setData}
//           data={props.data}
//           setIsModalOpen={setIsModalOpen}
//         />
//       </Modal>
//     </>
//   );
// };

// export default Dialogpage;
