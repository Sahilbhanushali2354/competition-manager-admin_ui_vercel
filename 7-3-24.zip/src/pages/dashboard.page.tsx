const Dashboard = () => {
  return (
    <div>
      <span style={{color:'rgb(105, 177, 255)',fontSize:'30px'}}>Welcome Admin</span>
    </div>
  );
};

export default Dashboard;
