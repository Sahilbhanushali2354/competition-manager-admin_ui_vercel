import { Button, Input, Space, Spin, message } from "antd";
import { ChangeEvent, useEffect, useState } from "react";
import { PeopleErrorDTO, UserDTO } from "../types/input.types";
import { useNavigate } from "react-router-dom";
import { addDoc, collection, doc, updateDoc } from "firebase/firestore";
import { FStore } from "../common/config/router/firebase.config";
import { useRecoilState } from "recoil";
import { AtomAllPeople } from "../store/atom.store";

interface Props {
  data?: UserDTO;
  setData?: (d: UserDTO[]) => void;
  setIsModalOpen?: (d: boolean) => void;
  disable?: boolean;
}

const People = (props: Props) => {
  const navigate = useNavigate();
  const [tableData, setTableData] = useRecoilState(AtomAllPeople);
  const [fields, setFields] = useState<UserDTO>(props.data || ({} as UserDTO));
  const [loader, setLoader] = useState(false);
  const [errorMessage, setErrorMessage] = useState<PeopleErrorDTO>({});
  const [userProfile, setUserProfile] = useState<File>();
  const isAllPeoplePage = props.data;
  const isPeoplePage = props.data;
  useEffect(() => {
    setFields(props.data || ({} as UserDTO));
  }, [props.data]);

  const handlechange = (e: ChangeEvent<HTMLInputElement>) => {
    let name = e.target.name;
    let value = e.target.value;
    setFields((prevfields) => ({ ...prevfields, [name]: value }));

    let _error = { ...errorMessage };

    if (!fields.email) _error = { ..._error, ["uname"]: "Enter Name" };
    else {
      _error = { ..._error, ["uname"]: "" };
    }
    if (!fields.email) _error = { ..._error, ["email"]: "Enter Email" };
    else {
      _error = { ..._error, ["email"]: "" };
    }
    if (!fields.contact)
      _error = { ..._error, ["contact"]: "Enter Phone Number" };
    else {
      _error = { ..._error, ["contact"]: "" };
    }
    if (!fields.address) _error = { ..._error, ["address"]: "Enter Address" };
    else {
      _error = { ..._error, ["address"]: "" };
    }
    setErrorMessage(_error);
  };
  const handleProfile = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setUserProfile(files[0]);

      const reader = new FileReader();
      reader.onload = () => {
        const base64String = reader.result?.toString();
        if (base64String) {
          // localStorage.setItem("profileImage", base64String);
          setFields((prevfields) => ({
            ...prevfields,
            ["profile"]: base64String,
          }));
        }
      };
      reader.readAsDataURL(files[0]);
    }
  };

  const handlesubmit = async () => {
    let _error = { ...errorMessage };
    if (!fields.uname) _error = { ..._error, ["uname"]: "Enter Username" };
    if (!fields.email) _error = { ..._error, ["email"]: "Enter Email" };
    if (!fields.contact)
      _error = { ..._error, ["contact"]: "Enter Phone Number" };
    if (!fields.profile)
      _error = { ..._error, ["profile"]: "Select Profile Photo" };
    /* console.log(_error); */
    if (fields.profile) {
      const extensions = [
        "image/apng",
        "image/avif",
        "image/gif",
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/svg+xml",
        "image/webp",
      ];
      if (userProfile && userProfile.name.length > 0) {
        if (!extensions.includes(userProfile.type)) {
          // console.log("--------userfile name", userProfile.name);

          // console.log("--------userfile", userProfile.type);
          _error = { ..._error, ["profile"]: "Enter Valid Profile Photo" };
          setErrorMessage(_error);
        }
      }
    }
    if (!fields.address) {
      _error = { ..._error, ["address"]: "Enter Address" };
      setErrorMessage(_error);
    }
    if (userProfile && userProfile.size < 1048.487) {
      _error = { ..._error, ["profile"]: "Enter Valid Profile Photo" };
      setErrorMessage(_error);
    } else {
      setLoader(true);
      await addData();
      // const existingDataJSON = localStorage.getItem("peopleList");
      // const existingData = existingDataJSON ? JSON.parse(existingDataJSON) : [];
      // const newData = [...existingData, fields];
      // localStorage.setItem("peopleList", JSON.stringify(newData));
      setFields({} as UserDTO);
      navigate("/allpeople");
      message.success("People Data Added Successfully");
      // console.log(fields.id);
    }
  };

  const addData = async () => {
    await addDoc(collection(FStore, "PEOPLE"), fields);
  };

  const handleupdate = async () => {
    // debugger;
    console.log("-------------------------->>>>props.data", props.data?.id);

    let _error = { ...errorMessage };
    if (!fields.uname) _error = { ..._error, ["uname"]: "Enter Username" };
    if (!fields.email) _error = { ..._error, ["email"]: "Enter Email" };
    if (!fields.contact)
      _error = { ..._error, ["contact"]: "Enter Phone Number" };

    if (!fields.address) {
      _error = { ..._error, ["address"]: "Enter Address" };
      setErrorMessage(_error);
    } else {
      if (props.data?.id && props.setData) {
        setLoader(true);
        const washingtonRef = doc(FStore, "PEOPLE", props.data?.id);
        let _tableData = [...tableData];
        let _data = _tableData.findIndex((x) => x.id == props.data?.id);
        if (_data !== -1) {
          _tableData.splice(_data, 1, fields);
          await updateDoc(washingtonRef, fields as {});
          // props.setData(fields as UserDTO[])
          setTableData(_tableData);
          props.setIsModalOpen && props.setIsModalOpen(false);
          message.success("People Data Updated SuccessFully");
        }
      }

      // const existingDataJSON = localStorage.getItem("peopleList");
      // const existingData = existingDataJSON ? JSON.parse(existingDataJSON) : [];
      // // const dataIndex = existingData.findIndex((item)=>item.email == fields.email)
      // const dataIndex = existingData.findIndex(
      //   (item: UserDTO) => item.email === fields.email
      // );
      // if (dataIndex !== -1) {
      //   existingData[dataIndex] = fields;
      //   localStorage.setItem("peopleList", JSON.stringify(existingData));
      //   props.setData && props.setData(existingData as UserDTO[]);
      //   props.setIsModalOpen && props.setIsModalOpen(false);
      //   message.success("People Data Updated Successfully");
      // }
    }
  };

  return (
    <Spin size="large" spinning={loader} className="main-container">
      <div className="container">
        <div className="form-container">
          {/* <div className="heading">
            <h3>Regitstration Form</h3>
          </div> */}
          <div className="input-container">
            <div className="inputs">
              <label>Name</label>
              <Input
                type="text"
                name="uname"
                onChange={handlechange}
                value={fields.uname}
              ></Input>
            </div>
          </div>
          <div style={{ color: "red", fontSize: "12px" }}>
            {errorMessage.uname}
          </div>
          <div className="input-container">
            <div className="inputs">
              <label>Email</label>
              <Input
                type="email"
                name="email"
                onChange={handlechange}
                value={fields.email}
                disabled={!!props.data}
              ></Input>
            </div>
          </div>
          <div style={{ color: "red", fontSize: "12px" }}>
            {errorMessage.email}
          </div>

          <div className="input-container">
            <div className="inputs">
              <label>Phone Number</label>
              <Input
                type="number"
                name="contact"
                onChange={handlechange}
                value={fields.contact}
              ></Input>
            </div>
          </div>
          <div style={{ color: "red", fontSize: "12px" }}>
            {errorMessage.contact}
          </div>

          <div className="input-container">
            <div className="inputs">
              <label>Photo</label>
              <Input
                type="file"
                name="profile"
                // value={fields.profile}
                onChange={handleProfile}
              ></Input>
            </div>
          </div>
          <div style={{ color: "red", fontSize: "12px" }}>
            {errorMessage.profile}
          </div>

          <div className="input-container">
            <div className="inputs">
              <label>Address</label>
              <Input
                type="text"
                name="address"
                onChange={handlechange}
                value={fields.address}
              ></Input>
            </div>
          </div>
          <div style={{ color: "red", fontSize: "12px" }}>
            {errorMessage.address}
          </div>

          <div style={{ padding: "10px" }}>
            <div className="inputs">
              {isAllPeoplePage ? null : (
                <Space>
                  <>
                    <Button type="primary" onClick={handlesubmit}>
                      Submit
                    </Button>
                    <Button
                      type="primary"
                      onClick={() => {
                        navigate("/allpeople");
                      }}
                    >
                      Back To AllPEOPLE
                    </Button>
                  </>
                </Space>
              )}
              {isPeoplePage ? (
                <Button type="primary" onClick={handleupdate}>
                  Update
                </Button>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </Spin>
  );
};

export default People;
