import { useNavigate } from "react-router-dom";
import {
  GoogleAuthProvider,
  User,
  signInWithPopup,
  signOut,
} from "firebase/auth";
import { FStore, auth } from "../common/config/router/firebase.config";
import { Avatar, Space, Spin, message } from "antd";
import { useRecoilState } from "recoil";
import { UserAtom } from "../store/atom.store";
import { AiOutlineGoogle } from "react-icons/ai";
import { addDoc, collection} from "firebase/firestore";
import { useState } from "react";
import { LoginDTO } from "../types/input.types";

// import firebase from "firebase/compat/app";

const Login = () => {
  const navigate = useNavigate();
  const [userlogin, setUserLogin] = useRecoilState(UserAtom);
  const [loader, setLoader] = useState(false);

  // useEffect(() => {
  //   const unsub = onAuthStateChanged(auth, (user) => {
  //     if (user) {
  //       console.log("-----user");

  //       navigate("/dashboard");
  //     }
  //   });
  //   return () => unsub();
  // }, [navigate]);

  const authentication = () => {
    // debugger;
    setLoader(true);
    const provider = new GoogleAuthProvider();
    signInWithPopup(auth, provider)
      .then(async (result) => {
        // This gives you a Google Access Token. You can use it to access the Google API.
        const credential = GoogleAuthProvider.credentialFromResult(result);
        const token = credential?.accessToken;
        console.log("---------user", token);
        
        // The signed-in user info.
        const user = result.user;
        console.log(user.email);
        console.log("----------------photoURL", user.photoURL);
        console.log("----------------uid", user.uid);
        console.log("----------------email", user.email);
        console.log("----------------displayname", user.displayName);
        setUserLogin(user);
        console.log(userlogin);
        addData(user);
        navigate("/dashboard");
        message.open({
          content: "Login SuccessFully",
          type: "success",
        });
        // IdP data available using getAdditionalUserInfo(result)
        // ...
      })
      .catch((error) => {
        setLoader(false);
        // Handle Errors here.

        // const errorCode = error.code;
        const errorMessage = error.message;
        // The email of the user's account used.
        // const email = error.customData.email;
        console.log(errorMessage);

        // The AuthCredential type that was used.
        // const credential = GoogleAuthProvider.credentialFromError(error);
        // ...
      });
  };
  const addData = async (user: User) => {
    debugger;
    let _user = {} as LoginDTO;
    _user.email = user.email;
    _user.contact = user.phoneNumber ?? "";
    _user.fullname = user.displayName ?? "";
    _user.id = user.uid;
    _user.photourl = user.photoURL ?? "";
    await addDoc(collection(FStore, "PEOPLE"), _user);
  };

  const signout = () => {
    signOut(auth).then(() => {
      console.log("-----------user logged out");
      // setUserLogin({})
      // navigate("/dashboard");
    });
  };
  return (
    <Spin spinning={loader} style={{ height: "100%", width: "100%" }}>
      <button onClick={signout}>sign out</button>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <h1>Sign in with Google</h1>
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "40vh",
        }}
      >
        <Space
          direction="vertical"
          style={{
            paddingRight: "7px",
            cursor: "pointer",
            backgroundColor: "black",
            borderRadius: "50px",
          }}
          size={16}
          onClick={authentication}
        >
          <Space wrap size={16}>
            <Avatar size={64} icon={<AiOutlineGoogle />} />
          </Space>
        </Space>
      </div>
    </Spin>
  );
};

export default Login;
