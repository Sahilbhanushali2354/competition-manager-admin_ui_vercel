// import { AiFillDelete } from "react-icons/ai";
// import { useState, useEffect } from "react";
// import { Button, Popconfirm, Table } from "antd";
// import { useNavigate } from "react-router-dom";
// import { collection, getDocs } from "firebase/firestore";
// import { FStore } from "../configs/firebase.config";
// import { UserDTO } from "../input.types";
// import Dialogpage from "./dialog";
// import Search from "antd/es/input/Search";
// import { doc, deleteDoc } from "firebase/firestore";

// const AllUsers = () => {
//   const [allUsersData, setAllUsersData] = useState<UserDTO[]>([]);
//   const [filteredUsers, setFilteredUsers] = useState<UserDTO[]>([]);

//   const navigate = useNavigate();

//   const columns = [
//     {
//       title: "Name",
//       dataIndex: "uname",
//     },
//     {
//       title: "Email",
//       dataIndex: "email",
//     },
//     {
//       title: "D.O.B",
//       dataIndex: "dob",
//     },
//     {
//       title: "Address",
//       dataIndex: "address",
//     },
//     {
//       title: "Designation",
//       dataIndex: "designation",
//     },
//     {
//       title: "Employee code",
//       dataIndex: "empcode",
//     },
//     {
//       title: "Edit",
//       render: (rowData: UserDTO) => {
//         return (
//           <Dialogpage
//             data={rowData}
//             setIsModalOpen={true}
//             setData={updatedData}
//           />
//         );
//       },
//     },
//     {
//       render: (rowData: UserDTO) => {
//         return (
//           <Popconfirm
//             title="Delete the Data"
//             description="Are you sure to delete this Data?"
//             onConfirm={() => deleteData(rowData)}
//           >
//             <Button
//               type="primary"
//               danger
//               icon={<AiFillDelete />}
//               style={{ border: "none", fontSize: "1.15rem" }}
//             ></Button>
//           </Popconfirm>
//         );
//       },
//     },
//   ];

//   const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     // debugger
//     const search = e.target.value.toLowerCase();
//     console.log("----search", search);
//     const filtered = allUsersData.filter((Item) =>
//       Object.values(Item).some((value) =>
//         String(value).toLowerCase().includes(search)
//       )
//     );
//     console.log("----filtered", filtered);
//     setFilteredUsers(filtered);
//   };
//   console.log(allUsersData);
//   const Getdata = async () => {
//     const querySnapshot = await getDocs(collection(FStore, "USERS"));
//     // console.log("-----formdataid", props.formdata?.id);

//     let x: any[] = [];

//     querySnapshot.forEach((doc) => {
//       // doc.data() is never undefined for query doc snapshots
//       console.log(doc.id, " => ", doc.data());
//       let _data = doc.data() as UserDTO;
//       _data.id = doc.id;
//       x.push(_data);
//     });
//     console.log(x);
//     setAllUsersData(x);
//     setFilteredUsers(x);
//   };

//   useEffect(() => {
//     Getdata();
//   }, []);

//   const updatedData = (formData: UserDTO, remove?: boolean) => {
//     // debugger;
//     console.log(formData);
//     let _allUsers = [...allUsersData];
//     let _filteredUsers = [...filteredUsers];

//     const iA = _allUsers.findIndex((x) => x.id === formData.id); //iA means for all users
//     remove
//       ? _allUsers.splice(iA, 1) //this is for delete if id is same otherwise edit operation will be done
//       : _allUsers.splice(iA, 1, formData);
//     const iF = _filteredUsers.findIndex((x) => x.id === formData.id); // iF means for filtered users
//     remove
//       ? _filteredUsers.splice(iF, 1) //for delete functionality
//       : _filteredUsers.splice(iF, 1, formData); // for edit functionality
//     setAllUsersData(_allUsers);
//     setFilteredUsers(_filteredUsers);
//   };
//   const deleteData = async (data: UserDTO) => {
//     await deleteDoc(doc(FStore, "USERS", data.id));
//     console.log("-------data", data);
//     updatedData(data, true);
//     // setFilteredUsers((newData) => newData.filter((Item) => Item.id != data.id));
//   };

//   return (
//     <>
//       <Search
//         style={{ width: "400px", float: "right" }}
//         onChange={handleSearchChange}
//       ></Search>
//       <Table dataSource={filteredUsers} columns={columns} />

//       <Button
//         type="primary"
//         onClick={() => {
//           navigate("/userRegister");
//         }}
//       >
//         ADD USER
//       </Button>
//     </>
//   );
// };
// export default AllUsers;
