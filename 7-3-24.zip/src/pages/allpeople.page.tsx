import { Button, Modal, Popconfirm, Table, message, Image } from "antd";
import { useEffect, useState } from "react";
import { FaUserEdit } from "react-icons/fa";
import { UserDTO } from "../types/input.types";
import People from "./peopleRegistration.page";
import { useNavigate } from "react-router-dom";
import { MdDeleteForever } from "react-icons/md";
import { collection, deleteDoc, doc, getDocs, query } from "firebase/firestore";
import { FStore } from "../common/config/router/firebase.config";
import { useRecoilState } from "recoil";
import { AtomAllPeople } from "../store/atom.store";

// interface Props {
//   //   data: UserDTO;
  // setData?: (d: UserDTO[]) => void;
//   setIsModalOpen: boolean;
//   disable:(d:boolean)=>void
// }

const AllPeople = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tableData, setTableData] = useRecoilState(AtomAllPeople);
  const [selectedRow, setSelectedRow] = useState<UserDTO>({} as UserDTO);
  const navigate = useNavigate();
  useEffect(() => {
    return () => {
      getdata();
    };
  }, []);

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const showModal = (rowData: UserDTO) => {
    setIsModalOpen(true);
    setSelectedRow(rowData);
    console.log("------------------rowdata", selectedRow);
  };

  const handleDelete = async (rowData: UserDTO) => {
    await deleteDoc(doc(FStore, "PEOPLE", rowData.id as string));

    console.log("--handleDelete", rowData);
    let _tableData = [...tableData];
    let x = _tableData.findIndex((x) => x.id == rowData.id);
    if (x !== -1) {
      _tableData.splice(rowData as any, 1);
      console.log("_tableData", _tableData);
      setTableData(_tableData);
      message.success('People Data Deleted Successfully')
    }
    // await deleteDoc(doc(FStore, "PEOPLE",rowData.id));

    // const existingDataJSON = localStorage.getItem("peopleList");
    // if (existingDataJSON) {
    //   const existingData: UserDTO[] = JSON.parse(existingDataJSON);
    //   const dataIndex = existingData.findIndex(
    //     (item: UserDTO) => item.email == rowData.email
    //   );
    //   if (dataIndex !== -1) {
    //     existingData.splice(dataIndex, 1);
    //     localStorage.setItem("peopleList", JSON.stringify(existingData));
    //     setTableData(existingData);
    //     message.success("People Data Deleted SuccessFully");
    //   }
    // }
  };

  // const updateData = () =>{
  //   let _tableData = [...tableData]
  //   let x = _tableData.findIndex((x)=>x.id == selectedRow.id)
  //   if(x){
  //     _tableData.splice(x,1)
  //   }else{

  //   }
  // }
  const columns = [
    {
      title: "Profile",
      dataIndex: "profile",
      render: (profile: string) => {
        // console.log('selected row',record.profile);

        return (
          <Image
            width={50} // Adjust the width as needed
            src={profile} // Set the src attribute to the base64 string
          />
        );
      },
    },
    {
      title: "Username",
      dataIndex: "uname",
    },
    {
      title: "Email",
      dataIndex: "email",
    },
    {
      title: "Phone Number",
      dataIndex: "contact",
    },
    {
      title: "Address",
      dataIndex: "address",
    },
    {
      title: "Edit",
      render: (rowData: UserDTO) => {
        // setSelectedRow(rowData);
        // console.log('--rowData',rowData);
        // debugger
        return (
          <Button
            icon={<FaUserEdit />}
            style={{ backgroundColor: "gray" }}
            onClick={() => showModal(rowData)}
          ></Button>
        );
      },
    },

    {
      title: "Delete",
      render: (rowData: UserDTO) => {
        return (
          <Popconfirm
            title="Delete the task"
            description="Are you sure to delete this Data?"
            onConfirm={() => handleDelete(rowData)}
            okText="Yes"
            cancelText="No"
          >
            <Button
              icon={<MdDeleteForever />}
              style={{ backgroundColor: "gray" }}
            ></Button>
          </Popconfirm>
        );
      },
    },
  ];

  const getdata = async () => {
    const x: UserDTO[] = [] as UserDTO[];
    // debugger
    // const storedData = localStorage.getItem("peopleList");
    // const parsedData = storedData && JSON.parse(storedData ?? "");
    // setTableData(parsedData);
    const q = query(collection(FStore, "PEOPLE"));

    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      console.log(doc.id, " => ", doc.data());
      let _data = doc.data();
      _data.id = doc.id;
      x.push(_data);
    });
    setTableData(x);
  };
  return (
    <div>
      <Table dataSource={tableData} columns={columns}></Table>
      <Modal
        footer={false}
        closable={true}
        open={isModalOpen}
        onCancel={handleCancel}
      >
        <People
          data={selectedRow}
          setData={setTableData}
          setIsModalOpen={setIsModalOpen}
          disable={!!selectedRow}
        />
      </Modal>
      <Button type="primary" onClick={() => navigate("/people")}>
        ADD PEOPLE
      </Button>
    </div>
  );
};

export default AllPeople;
