import {
  Avatar,
  Breadcrumb,
  Button,
  Dropdown,
  Layout,
  Menu,
  MenuProps,
  Space,
  notification,
  theme,
} from "antd";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { UserOutlined } from "@ant-design/icons";
import "../index.css";
import { useRecoilValue } from "recoil";
import { UserAtom } from "../store/atom.store";
import { signOut } from "firebase/auth";
import { auth } from "../common/config/router/firebase.config";
const { Header, Content, Sider } = Layout;

const Mainlayout = () => {
  const navigate = useNavigate();
  const userlogin = useRecoilValue(UserAtom);

  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  const path = useLocation().pathname;

  const items2: MenuProps["items"] = [
    {
      key: "/dashboard",
      label: <Link to="/dashboard">Home</Link>,
    },
    {
      key: "/competition",
      label: <Link to="/competition">Competition</Link>,
    },
    {
      key: "/people",
      label: <Link to="/people">People</Link>,
    },
    {
      key: "/allpeople",
      label: <Link to="/allpeople">All People</Link>,
    },
  ];
  const signout = () => {
    // debugger
    // navigate("/login");
    // navigate(0);

    signOut(auth)
      .then(() => {
        navigate("/login");

        // setUserLogin({})
      })
      .catch((error) => {
        console.log(error, "------------------logour error");
        notification.open({ message: error, type: error });
      });
  };

  const items: MenuProps["items"] = [
    {
      key: "name",
      label: <label style={{ color: "#69b1ff" }}>{userlogin?.email} </label>,
    },
    {
      key: "/login",
      label: (
        <Button
          onClick={() => {
            signout();
          }}
        >
          Log out
        </Button>
      ),
    },
  ];

  // useEffect(() => {
  //   const unsub = onAuthStateChanged(auth, (user) => {
  //     if (!user) {
  //       navigate("/login");
  //     }
  //   });
  //   return () => unsub();
  // }, [navigate]);

  return (
    <Layout>
      <Header
        style={{
          padding: "0",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Link to="/" style={{ paddingLeft: "30px" }}>
          Protocol Zone
        </Link>

        <Dropdown menu={{ items }}>
          <Space direction="vertical" style={{ paddingRight: "7px" }} size={16}>
            <Space wrap size={16}>
              <Avatar size={48} icon={<UserOutlined />} />
            </Space>
          </Space>
        </Dropdown>
      </Header>
      <Layout>
        <Sider width={200} style={{ background: colorBgContainer }}>
          <Menu
            mode="inline"
            activeKey={path}
            selectedKeys={[path]}
            defaultSelectedKeys={["1"]}
            defaultOpenKeys={["sub1"]}
            style={{ height: "100%", borderRight: 0 }}
            items={items2}
          />
        </Sider>
        <Layout style={{ padding: "0 24px 24px" }}>
          <Breadcrumb
            style={{ margin: "16px 0" }}
            items={[
              { title: <Link to="/">Home</Link> },
              { title: <Link to={{ path }}>{path.replace("/", "")}</Link> },
            ]}
          ></Breadcrumb>
          <Content
            style={{
              padding: 24,
              margin: 0,
              minHeight: 280,
              background: colorBgContainer,
              borderRadius: borderRadiusLG,
            }}
          >
            <Outlet />
          </Content>
        </Layout>
      </Layout>
    </Layout>
    // <Layout>
    //   <Header style={{ display: "flex", alignItems: "center" }}>
    //     <Menu
    //       theme="dark"
    //       mode="horizontal"
    //       items={items}
    //       activeKey={path}
    //       selectedKeys={[path]}
    //       style={{ flex: 1, minWidth: 0, height: "100%", width: "100%" }}
    //     />
    //   </Header>
    //   <Content style={{ padding: "0 48px" }}>
    // <Breadcrumb style={{ margin: "16px 0" }}>
    //   <Breadcrumb.Item>Home</Breadcrumb.Item>
    //   <Breadcrumb.Item>{path.split("/")}</Breadcrumb.Item>
    // </Breadcrumb>
    //     <div
    //       style={{
    //         background: colorBgContainer,
    //         minHeight: 280,
    //         padding: 24,
    //         borderRadius: borderRadiusLG,
    //       }}
    //     >
    //       <Outlet />
    //     </div>
    //   </Content>
    // </Layout>
  );
};

export default Mainlayout;
