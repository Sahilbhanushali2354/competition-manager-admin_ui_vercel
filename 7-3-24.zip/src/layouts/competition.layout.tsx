import { Card, Button, Modal, Input } from "antd";
import { Link, Outlet } from "react-router-dom";
import { IoAddSharp } from "react-icons/io5";
import { ChangeEvent, useEffect, useState } from "react";
import { CompetitionDTO, TError } from "../types/input.types";
import { addDoc, collection, getDocs } from "firebase/firestore";
import { FStore } from "../common/config/router/firebase.config";
import { useRecoilState } from "recoil";
import {
  AllCompetitionAtom,
  SelectedCompetitionAtom,
} from "../store/atom.store";

const Competitionlayout = () => {
  // const { id } = useParams();
  // console.log('--------------id',id)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [competitionName, setCompetitionName] = useState<CompetitionDTO>(
    {} as CompetitionDTO
  );
  const [allcompetitionData, setAllCompetitionData] =
    useRecoilState(AllCompetitionAtom);
  const [selectedCompetition, setSelectedCompetition] =
    useRecoilState<CompetitionDTO>(SelectedCompetitionAtom);
  const [errorMessage, setErrorMessage] = useState<TError>({} as TError);

  useEffect(() => {
    getdata();
  }, []);

  const showModal = () => {
    setIsModalOpen(true);
    console.log(selectedCompetition);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
    setCompetitionName({} as CompetitionDTO);
  };

  const handlechange = (e: ChangeEvent<HTMLInputElement>) => {
    // let cname = e.target.name;
    // console.log(cname);

    let val = e.target.value.replace(/ /g, "_");
    // console.log(val);

    const x = { ...competitionName };
    x.cname = e.target.value;
    x.cid = val.toLowerCase();
    setCompetitionName(x);
    let _error = { ...errorMessage };
    if (!val) _error = { ..._error, ["cname"]: "Enter Competition Name" };
    if (val) _error = { ..._error, ["cname"]: "" };
    setErrorMessage(_error);
  };
  // console.log(selectedCompetition);

  const handlesubmit = async () => {
    // debugger;
    if (!competitionName?.cname) {
      setErrorMessage({
        ...errorMessage,
        ["cname"]: "First Enter Competition Name",
      });
    }
    // console.log("----------competitionName?.cid", competitionName?.cid);
    else {
      await addData();
      getdata();
      handleCancel();
    }
  };

  // console.log("--------------allcompetitiondata", allcompetitionData);

  const addData = async () => {
    // debugger
    let competitionround = {
      ...competitionName,
      rounds: [{ id: "1", label: "Round 1" }],
    };
    await addDoc(collection(FStore, "COMPETITION"), competitionround);
  };

  const getdata = async () => {
    // debugger;
    const querySnapshot = await getDocs(collection(FStore, "COMPETITION"));
    let x: CompetitionDTO[] = [] as CompetitionDTO[];

    querySnapshot.forEach((doc) => {
      // debugger
      // console.log("-----doc.data", doc.data());
      let _data = doc.data();
      _data.id = doc.id;
      x.push(_data as CompetitionDTO);
    });
    setAllCompetitionData(x);
  };

  return (
    <>
      <div style={{ float: "right" }}>
        <Button
          style={{ backgroundColor: "#69b1ff" }}
          icon={<IoAddSharp />}
          onClick={showModal}
        ></Button>
      </div>
      {allcompetitionData.length == 0 ? (
        <h2 style={{ color: "#69b1ff" }}>CLICK ON ADD BUTTON TO ADD CARDS</h2>
      ) : (
        <div style={{ display: "flex", flexDirection: "row" }}>
          {allcompetitionData.map((selectedCard) => {
            return (
              <Link
                key={selectedCard.id}
                onClick={() => setSelectedCompetition(selectedCard)}
                to={`/competition/${selectedCard.id}`}
              >
                <div style={{ padding: "2px" }}>
                  <Card
                    key={selectedCard.cid}
                    style={{ width: "auto", border: "1px solid #69b1ff" }}
                  >
                    <span>{selectedCard.cname}</span>
                  </Card>
                </div>
              </Link>
            );
          })}
        </div>
      )}

      <Modal
        onCancel={handleCancel}
        footer={false}
        title="ADD COMPETITION"
        open={isModalOpen}
        closable={true}
      >
        <label>Competition Name </label>
        <Input
          name="cname"
          onChange={handlechange}
          value={competitionName?.cname}
        ></Input>
        <div style={{ color: "red", fontSize: "12px" }}>
          {errorMessage.cname}
        </div>
        <label>Competition ID</label>
        <Input
          disabled
          name="id"
          value={competitionName?.cid}
          onChange={handlechange}
        ></Input>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginTop: "10px",
          }}
        >
          <Button onClick={handlesubmit} type="primary">
            ADD COMPETITION
          </Button>
          <Button type="default" onClick={handleCancel}>
            Back
          </Button>
        </div>
      </Modal>
      <Outlet />
    </>
  );
};

export default Competitionlayout;
